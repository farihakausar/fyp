import React from 'react'

export default function CourseMateril() {
  return (
    <div>CourseMateril</div>
  )
}
