import React from 'react'

export default function EditProfile() {
  return (
    <div>EditProfile</div>
  )
}
